// ============================================================
// app/src/manage.ts
// Manager CLI — deploy vault, record profits, check stats
// Run: npx ts-node src/manage.ts <command>
// ============================================================

import { Connection, Keypair, PublicKey, LAMPORTS_PER_SOL } from "@solana/web3.js";
import { VaultClient, getVaultPDA } from "./vault-client";
import bs58 from "bs58";
import dotenv from "dotenv";

dotenv.config({ path: "../../.env" });

const RPC = process.env.RPC_ENDPOINT ?? "https://api.devnet.solana.com";
const connection = new Connection(RPC, "confirmed");

async function main() {
  const command = process.argv[2];

  if (!process.env.PRIVATE_KEY) {
    console.error("❌ PRIVATE_KEY not set in .env");
    process.exit(1);
  }

  const wallet = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY));
  const client = new VaultClient(connection, wallet.publicKey);

  console.log(`\n🔑 Manager wallet: ${wallet.publicKey.toBase58()}`);
  console.log(`🌐 RPC: ${RPC}\n`);

  switch (command) {

    // ── Check vault status ──────────────────────────────────
    case "status": {
      const vault = await client.getVaultState();
      if (!vault) {
        console.log("❌ Vault not found. Run 'initialize' first.");
        break;
      }
      console.log(client.formatVaultSummary(vault));
      break;
    }

    // ── Check a depositor's position ────────────────────────
    case "depositor": {
      const depositorAddress = process.argv[3];
      if (!depositorAddress) {
        console.error("Usage: manage.ts depositor <WALLET_ADDRESS>");
        break;
      }
      const vault = await client.getVaultState();
      if (!vault) { console.log("❌ Vault not found"); break; }

      const depositorPubkey = new PublicKey(depositorAddress);
      const depositor = await client.getDepositorState(depositorPubkey, vault);
      if (!depositor) {
        console.log("❌ Depositor not found in this vault");
        break;
      }
      console.log(client.formatDepositorSummary(depositor));
      break;
    }

    // ── Show vault PDA addresses ────────────────────────────
    case "addresses": {
      const [vaultPDA] = getVaultPDA(wallet.publicKey);
      console.log("Vault PDA:     ", vaultPDA.toBase58());
      console.log("Share this with depositors so they can verify on-chain.");
      break;
    }

    // ── Help ────────────────────────────────────────────────
    default: {
      console.log(`
SOL Vault Manager CLI
─────────────────────
Commands:
  status              Show vault stats (TVL, profit, depositors)
  depositor <addr>    Show a specific depositor's position
  addresses           Show vault PDA addresses

Examples:
  npx ts-node src/manage.ts status
  npx ts-node src/manage.ts depositor DUyAnt9FVguy8sRQbRuNSW1tuToJfcqWq5sgwYRBtdF6
  npx ts-node src/manage.ts addresses
`);
    }
  }
}

main().catch(console.error);
