// ============================================================
// app/src/vault-client.ts
// TypeScript SDK to interact with the SOL Vault smart contract
// Works with Phantom wallet or any Solana wallet adapter
// ============================================================

import {
  Connection,
  PublicKey,
  Keypair,
  SystemProgram,
  Transaction,
  sendAndConfirmTransaction,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";

// ── Constants ─────────────────────────────────────────────────

const PROGRAM_ID = new PublicKey("VAULT_PROGRAM_ID_REPLACE_AFTER_DEPLOY");

// ── PDA Helpers ───────────────────────────────────────────────

export async function getVaultPDA(managerPubkey: PublicKey): Promise<[PublicKey, number]> {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("vault"), managerPubkey.toBuffer()],
    PROGRAM_ID
  );
}

export async function getVaultSolPDA(vaultPubkey: PublicKey): Promise<[PublicKey, number]> {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("vault_sol"), vaultPubkey.toBuffer()],
    PROGRAM_ID
  );
}

export async function getDepositorPDA(
  vaultPubkey: PublicKey,
  depositorPubkey: PublicKey
): Promise<[PublicKey, number]> {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("depositor"), vaultPubkey.toBuffer(), depositorPubkey.toBuffer()],
    PROGRAM_ID
  );
}

// ── Vault State Reader ────────────────────────────────────────

export interface VaultState {
  manager: string;
  totalShares: number;
  totalSolLamports: number;
  totalSolSOL: number;
  totalProfitEarned: number;
  totalFeesCollected: number;
  performanceFeeBps: number;
  minDepositLamports: number;
  withdrawalLockupSeconds: number;
  depositorCount: number;
  createdAt: Date;
  lastProfitUpdate: Date;
  isPaused: boolean;
}

export interface DepositorState {
  depositor: string;
  shares: number;
  sharePercent: number;
  depositedLamports: number;
  depositedSOL: number;
  estimatedCurrentValueSOL: number;
  estimatedProfitSOL: number;
  totalWithdrawnSOL: number;
  depositDate: Date;
  lastWithdrawDate: Date;
  nextWithdrawDate: Date;
  canWithdrawNow: boolean;
}

export class VaultClient {
  private connection: Connection;
  private managerPubkey: PublicKey;

  constructor(connection: Connection, managerPubkey: PublicKey) {
    this.connection = connection;
    this.managerPubkey = managerPubkey;
  }

  // ── Read vault state ────────────────────────────────────────

  async getVaultState(): Promise<VaultState | null> {
    try {
      const [vaultPDA] = getVaultPDA(this.managerPubkey);
      const accountInfo = await this.connection.getAccountInfo(vaultPDA);
      if (!accountInfo) return null;

      // Parse account data (skip 8-byte discriminator)
      const data = accountInfo.data.slice(8);
      let offset = 0;

      const manager = new PublicKey(data.slice(offset, offset + 32)).toBase58();
      offset += 32;
      const totalShares = Number(data.readBigUInt64LE(offset)); offset += 8;
      const totalSolLamports = Number(data.readBigUInt64LE(offset)); offset += 8;
      const totalProfitEarned = Number(data.readBigUInt64LE(offset)); offset += 8;
      const totalFeesCollected = Number(data.readBigUInt64LE(offset)); offset += 8;
      const performanceFeeBps = Number(data.readBigUInt64LE(offset)); offset += 8;
      const minDepositLamports = Number(data.readBigUInt64LE(offset)); offset += 8;
      const withdrawalLockupSeconds = Number(data.readBigInt64LE(offset)); offset += 8;
      const depositorCount = Number(data.readBigUInt64LE(offset)); offset += 8;
      const createdAt = Number(data.readBigInt64LE(offset)); offset += 8;
      const lastProfitUpdate = Number(data.readBigInt64LE(offset)); offset += 8;
      const isPaused = data[offset] === 1;

      return {
        manager,
        totalShares,
        totalSolLamports,
        totalSolSOL: totalSolLamports / LAMPORTS_PER_SOL,
        totalProfitEarned: totalProfitEarned / LAMPORTS_PER_SOL,
        totalFeesCollected: totalFeesCollected / LAMPORTS_PER_SOL,
        performanceFeeBps,
        minDepositLamports,
        withdrawalLockupSeconds,
        depositorCount,
        createdAt: new Date(createdAt * 1000),
        lastProfitUpdate: new Date(lastProfitUpdate * 1000),
        isPaused,
      };
    } catch (err) {
      console.error("Failed to read vault state:", err);
      return null;
    }
  }

  // ── Read depositor state ────────────────────────────────────

  async getDepositorState(
    depositorPubkey: PublicKey,
    vaultState: VaultState
  ): Promise<DepositorState | null> {
    try {
      const [vaultPDA] = getVaultPDA(this.managerPubkey);
      const [depositorPDA] = getDepositorPDA(vaultPDA, depositorPubkey);
      const accountInfo = await this.connection.getAccountInfo(depositorPDA);
      if (!accountInfo) return null;

      const data = accountInfo.data.slice(8);
      let offset = 0;

      const depositor = new PublicKey(data.slice(offset, offset + 32)).toBase58(); offset += 32;
      offset += 32; // vault pubkey
      const shares = Number(data.readBigUInt64LE(offset)); offset += 8;
      const depositedLamports = Number(data.readBigUInt64LE(offset)); offset += 8;
      const totalWithdrawn = Number(data.readBigUInt64LE(offset)); offset += 8;
      const depositTimestamp = Number(data.readBigInt64LE(offset)); offset += 8;
      const lastWithdrawTimestamp = Number(data.readBigInt64LE(offset));

      // Calculate current value based on share ownership
      const sharePercent = vaultState.totalShares > 0
        ? (shares / vaultState.totalShares) * 100
        : 0;

      const estimatedCurrentValueLamports = vaultState.totalShares > 0
        ? (shares / vaultState.totalShares) * vaultState.totalSolLamports
        : 0;

      const estimatedCurrentValueSOL = estimatedCurrentValueLamports / LAMPORTS_PER_SOL;
      const depositedSOL = depositedLamports / LAMPORTS_PER_SOL;
      const estimatedProfitSOL = estimatedCurrentValueSOL - depositedSOL + (totalWithdrawn / LAMPORTS_PER_SOL);

      const now = Date.now() / 1000;
      const nextWithdrawTimestamp = lastWithdrawTimestamp + vaultState.withdrawalLockupSeconds;
      const canWithdrawNow = now >= nextWithdrawTimestamp;

      return {
        depositor,
        shares,
        sharePercent,
        depositedLamports,
        depositedSOL,
        estimatedCurrentValueSOL,
        estimatedProfitSOL,
        totalWithdrawnSOL: totalWithdrawn / LAMPORTS_PER_SOL,
        depositDate: new Date(depositTimestamp * 1000),
        lastWithdrawDate: new Date(lastWithdrawTimestamp * 1000),
        nextWithdrawDate: new Date(nextWithdrawTimestamp * 1000),
        canWithdrawNow,
      };
    } catch (err) {
      console.error("Failed to read depositor state:", err);
      return null;
    }
  }

  // ── Format helpers ──────────────────────────────────────────

  formatVaultSummary(vault: VaultState): string {
    return `
╔══════════════════════════════════════════╗
║           SOL ARB VAULT STATUS           ║
╠══════════════════════════════════════════╣
║  Total SOL:      ${vault.totalSolSOL.toFixed(4).padEnd(24)} ║
║  Depositors:     ${vault.depositorCount.toString().padEnd(24)} ║
║  Total Profit:   ${vault.totalProfitEarned.toFixed(4).padEnd(24)} ║
║  Fees Earned:    ${vault.totalFeesCollected.toFixed(4).padEnd(24)} ║
║  Status:         ${(vault.isPaused ? "PAUSED" : "ACTIVE").padEnd(24)} ║
║  Last Profit:    ${vault.lastProfitUpdate.toLocaleDateString().padEnd(24)} ║
╚══════════════════════════════════════════╝`;
  }

  formatDepositorSummary(d: DepositorState): string {
    return `
╔══════════════════════════════════════════╗
║         YOUR VAULT POSITION              ║
╠══════════════════════════════════════════╣
║  Deposited:      ${d.depositedSOL.toFixed(4)} SOL              ║
║  Current Value:  ${d.estimatedCurrentValueSOL.toFixed(4)} SOL              ║
║  Profit:         ${d.estimatedProfitSOL >= 0 ? "+" : ""}${d.estimatedProfitSOL.toFixed(4)} SOL              ║
║  Share:          ${d.sharePercent.toFixed(2)}%                     ║
║  Can Withdraw:   ${d.canWithdrawNow ? "YES ✅" : "NO (locked)"}                 ║
║  Next Withdraw:  ${d.nextWithdrawDate.toLocaleDateString()}                 ║
╚══════════════════════════════════════════╝`;
  }
}
