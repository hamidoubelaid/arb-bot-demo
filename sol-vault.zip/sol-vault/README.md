# ◆ SOL Arb Vault — Smart Contract

A Solana smart contract (program) that manages a multi-depositor arbitrage fund.
Built with the Anchor framework in Rust.

---

## What it does

```
Depositor A sends 1 SOL ──┐
Depositor B sends 2 SOL ──┼──▶ Vault PDA (holds all SOL)
Depositor C sends 0.5 SOL ┘         │
                                     ▼
                              Bot trades with pooled SOL
                                     │
                              Manager calls record_profit()
                                     │
                    ┌────────────────┴────────────────┐
                    ▼                                 ▼
             25% fee → Manager              75% stays in vault
                                                     │
                                            Depositors withdraw
                                            proportional share
```

---

## Vault Terms (hardcoded in contract)

| Parameter | Value |
|-----------|-------|
| Minimum deposit | 0.5 SOL |
| Performance fee | 25% of profits |
| Withdrawal lockup | 7 days |
| Max depositors | 100 |

---

## Setup

### Prerequisites

```bash
# Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install Solana CLI
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"

# Install Anchor
cargo install --git https://github.com/coral-xyz/anchor avm --locked
avm install latest
avm use latest

# Install Node deps
cd app && npm install
```

### Configure wallet

```bash
# Use your existing bot wallet
solana config set --keypair ~/.config/solana/id.json
solana config set --url devnet
```

---

## Deploy to Devnet (test first)

```bash
# Build the program
anchor build

# Get your program ID
solana address -k target/deploy/sol_vault-keypair.json

# Replace VAULT_PROGRAM_ID_REPLACE_AFTER_DEPLOY in:
#   - programs/sol-vault/src/lib.rs  (declare_id!)
#   - Anchor.toml
#   - app/src/vault-client.ts

# Rebuild with correct ID
anchor build

# Deploy to devnet
anchor deploy --provider.cluster devnet

# Initialize the vault (run once)
cd app && npx ts-node src/manage.ts initialize
```

---

## Deploy to Mainnet

```bash
# Switch to mainnet
solana config set --url mainnet-beta

# Ensure wallet has ~2 SOL for deployment rent
solana balance

# Deploy
anchor deploy --provider.cluster mainnet

# Initialize vault
cd app && npx ts-node src/manage.ts initialize
```

---

## Usage

### Manager commands

```bash
# Check vault status
npx ts-node src/manage.ts status

# Check a depositor's position
npx ts-node src/manage.ts depositor <WALLET_ADDRESS>

# Get vault PDA addresses
npx ts-node src/manage.ts addresses
```

### Investor portal

Open `investor-portal.html` in a browser. Investors can:
- Connect Phantom wallet
- Preview deposit shares
- Check their position
- Request withdrawals

---

## Smart contract instructions

| Instruction | Who calls it | What it does |
|-------------|-------------|--------------|
| `initialize` | Manager (once) | Creates the vault |
| `deposit` | Any investor | Sends SOL, receives shares |
| `record_profit` | Manager | Logs profit, takes 25% fee |
| `withdraw` | Any investor | Burns shares, receives SOL |
| `set_paused` | Manager | Pause/unpause deposits |

---

## Security notes

- The smart contract is non-custodial — funds live in a PDA, not your wallet
- Withdrawals always remain open even when vault is paused
- Manager can only take the 25% fee via `record_profit` — cannot drain vault
- All transactions are on-chain and publicly auditable
- Weekly lockup prevents bank-run scenarios

---

## File structure

```
sol-vault/
├── programs/sol-vault/
│   ├── src/lib.rs          Main smart contract (Rust/Anchor)
│   └── Cargo.toml
├── app/
│   └── src/
│       ├── vault-client.ts TypeScript SDK
│       └── manage.ts       Manager CLI
├── Anchor.toml
└── README.md
```
