// ============================================================
// sol_vault/src/lib.rs
// SOL Arbitrage Vault Smart Contract
//
// Features:
//   - Multi-depositor vault with share-based accounting
//   - 25% performance fee paid to manager
//   - Weekly withdrawal windows
//   - 0.5 SOL minimum deposit
//   - Fully on-chain, trustless profit distribution
// ============================================================

use anchor_lang::prelude::*;
use anchor_lang::system_program;

declare_id!("VAULT_PROGRAM_ID_REPLACE_AFTER_DEPLOY");

// ── Constants ─────────────────────────────────────────────────

/// Minimum deposit: 0.5 SOL in lamports
const MIN_DEPOSIT_LAMPORTS: u64 = 500_000_000;

/// Performance fee: 25% = 2500 basis points
const PERFORMANCE_FEE_BPS: u64 = 2500;

/// Withdrawal lockup: 7 days in seconds
const WITHDRAWAL_LOCKUP_SECONDS: i64 = 7 * 24 * 60 * 60;

/// Max depositors per vault (to bound account size)
const MAX_DEPOSITORS: usize = 100;

/// Basis points denominator
const BPS_DENOMINATOR: u64 = 10_000;

// ── Program ───────────────────────────────────────────────────

#[program]
pub mod sol_vault {
    use super::*;

    // ── Initialize vault ─────────────────────────────────────

    /// Called once by the manager to create the vault.
    /// Sets manager wallet, fee parameters, and withdrawal schedule.
    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        let clock = Clock::get()?;

        vault.manager = ctx.accounts.manager.key();
        vault.total_shares = 0;
        vault.total_sol = 0;
        vault.total_profit_earned = 0;
        vault.total_fees_collected = 0;
        vault.performance_fee_bps = PERFORMANCE_FEE_BPS;
        vault.min_deposit_lamports = MIN_DEPOSIT_LAMPORTS;
        vault.withdrawal_lockup_seconds = WITHDRAWAL_LOCKUP_SECONDS;
        vault.depositor_count = 0;
        vault.created_at = clock.unix_timestamp;
        vault.last_profit_update = clock.unix_timestamp;
        vault.is_paused = false;
        vault.bump = ctx.bumps.vault;

        emit!(VaultInitialized {
            manager: vault.manager,
            timestamp: clock.unix_timestamp,
        });

        msg!("Vault initialized. Manager: {}", vault.manager);
        Ok(())
    }

    // ── Deposit ───────────────────────────────────────────────

    /// Depositor sends SOL to the vault and receives shares proportional
    /// to their contribution relative to the total vault balance.
    pub fn deposit(ctx: Context<Deposit>, amount_lamports: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        let depositor_account = &mut ctx.accounts.depositor_account;
        let clock = Clock::get()?;

        // Checks
        require!(!vault.is_paused, VaultError::VaultPaused);
        require!(
            amount_lamports >= vault.min_deposit_lamports,
            VaultError::BelowMinimumDeposit
        );
        require!(
            vault.depositor_count < MAX_DEPOSITORS as u64,
            VaultError::VaultFull
        );

        // Calculate shares to mint
        // First deposit: shares = lamports (1:1)
        // Subsequent: shares = (amount / total_sol) * total_shares
        let shares_to_mint = if vault.total_shares == 0 || vault.total_sol == 0 {
            amount_lamports
        } else {
            (amount_lamports as u128)
                .checked_mul(vault.total_shares as u128)
                .unwrap()
                .checked_div(vault.total_sol as u128)
                .unwrap() as u64
        };

        require!(shares_to_mint > 0, VaultError::ZeroShares);

        // Transfer SOL from depositor to vault PDA
        let transfer_ix = system_program::Transfer {
            from: ctx.accounts.depositor.to_account_info(),
            to: ctx.accounts.vault_sol.to_account_info(),
        };
        system_program::transfer(
            CpiContext::new(
                ctx.accounts.system_program.to_account_info(),
                transfer_ix,
            ),
            amount_lamports,
        )?;

        // Update depositor account
        if depositor_account.depositor == Pubkey::default() {
            // New depositor
            depositor_account.depositor = ctx.accounts.depositor.key();
            depositor_account.vault = vault.key();
            depositor_account.shares = shares_to_mint;
            depositor_account.deposited_lamports = amount_lamports;
            depositor_account.deposit_timestamp = clock.unix_timestamp;
            depositor_account.last_withdraw_timestamp = clock.unix_timestamp;
            depositor_account.total_withdrawn = 0;
            depositor_account.bump = ctx.bumps.depositor_account;
            vault.depositor_count = vault.depositor_count.checked_add(1).unwrap();
        } else {
            // Existing depositor adding more
            depositor_account.shares = depositor_account.shares.checked_add(shares_to_mint).unwrap();
            depositor_account.deposited_lamports = depositor_account
                .deposited_lamports
                .checked_add(amount_lamports)
                .unwrap();
        }

        // Update vault totals
        vault.total_shares = vault.total_shares.checked_add(shares_to_mint).unwrap();
        vault.total_sol = vault.total_sol.checked_add(amount_lamports).unwrap();

        emit!(Deposited {
            depositor: ctx.accounts.depositor.key(),
            amount_lamports,
            shares_minted: shares_to_mint,
            total_vault_sol: vault.total_sol,
            timestamp: clock.unix_timestamp,
        });

        msg!(
            "Deposit: {} lamports, {} shares minted. Vault total: {} lamports",
            amount_lamports,
            shares_to_mint,
            vault.total_sol
        );

        Ok(())
    }

    // ── Record Profit ─────────────────────────────────────────

    /// Called by the manager after a profitable trading session.
    /// Calculates performance fee and updates vault balance.
    /// The actual SOL profit should already be in the vault_sol account.
    pub fn record_profit(ctx: Context<RecordProfit>, profit_lamports: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        let clock = Clock::get()?;

        require!(
            ctx.accounts.manager.key() == vault.manager,
            VaultError::Unauthorized
        );
        require!(profit_lamports > 0, VaultError::ZeroProfit);
        require!(!vault.is_paused, VaultError::VaultPaused);

        // Calculate performance fee (25% of profit)
        let fee_lamports = profit_lamports
            .checked_mul(vault.performance_fee_bps)
            .unwrap()
            .checked_div(BPS_DENOMINATOR)
            .unwrap();

        let net_profit = profit_lamports.checked_sub(fee_lamports).unwrap();

        // Transfer fee to manager
        // (vault_sol → manager via CPI, vault has authority via PDA)
        let vault_key = vault.key();
        let seeds = &[b"vault_sol", vault_key.as_ref(), &[ctx.bumps.vault_sol]];
        let signer_seeds = &[&seeds[..]];

        let fee_transfer = system_program::Transfer {
            from: ctx.accounts.vault_sol.to_account_info(),
            to: ctx.accounts.manager.to_account_info(),
        };
        system_program::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.system_program.to_account_info(),
                fee_transfer,
                signer_seeds,
            ),
            fee_lamports,
        )?;

        // Update vault: net profit stays for depositors
        vault.total_sol = vault.total_sol.checked_add(net_profit).unwrap();
        vault.total_profit_earned = vault.total_profit_earned.checked_add(profit_lamports).unwrap();
        vault.total_fees_collected = vault.total_fees_collected.checked_add(fee_lamports).unwrap();
        vault.last_profit_update = clock.unix_timestamp;

        emit!(ProfitRecorded {
            profit_lamports,
            fee_lamports,
            net_profit,
            manager: vault.manager,
            timestamp: clock.unix_timestamp,
        });

        msg!(
            "Profit recorded: {} lamports gross, {} fee, {} net to depositors",
            profit_lamports,
            fee_lamports,
            net_profit
        );

        Ok(())
    }

    // ── Withdraw ──────────────────────────────────────────────

    /// Depositor withdraws their proportional share of the vault.
    /// Enforces weekly lockup — can only withdraw once per 7 days.
    pub fn withdraw(ctx: Context<Withdraw>, shares_to_burn: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        let depositor_account = &mut ctx.accounts.depositor_account;
        let clock = Clock::get()?;

        // Authorization
        require!(
            depositor_account.depositor == ctx.accounts.depositor.key(),
            VaultError::Unauthorized
        );

        // Weekly lockup check
        let time_since_last_withdraw = clock
            .unix_timestamp
            .checked_sub(depositor_account.last_withdraw_timestamp)
            .unwrap();

        require!(
            time_since_last_withdraw >= vault.withdrawal_lockup_seconds,
            VaultError::WithdrawalLocked
        );

        // Share validation
        require!(shares_to_burn > 0, VaultError::ZeroShares);
        require!(
            shares_to_burn <= depositor_account.shares,
            VaultError::InsufficientShares
        );

        // Calculate SOL to return based on share ownership
        // withdrawal_sol = (shares_to_burn / total_shares) * total_sol
        let sol_to_return = (shares_to_burn as u128)
            .checked_mul(vault.total_sol as u128)
            .unwrap()
            .checked_div(vault.total_shares as u128)
            .unwrap() as u64;

        require!(sol_to_return > 0, VaultError::ZeroWithdrawal);

        // Transfer SOL from vault_sol PDA to depositor
        let vault_key = vault.key();
        let seeds = &[b"vault_sol", vault_key.as_ref(), &[ctx.bumps.vault_sol]];
        let signer_seeds = &[&seeds[..]];

        let transfer_ix = system_program::Transfer {
            from: ctx.accounts.vault_sol.to_account_info(),
            to: ctx.accounts.depositor.to_account_info(),
        };
        system_program::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.system_program.to_account_info(),
                transfer_ix,
                signer_seeds,
            ),
            sol_to_return,
        )?;

        // Update state
        depositor_account.shares = depositor_account.shares.checked_sub(shares_to_burn).unwrap();
        depositor_account.total_withdrawn = depositor_account.total_withdrawn.checked_add(sol_to_return).unwrap();
        depositor_account.last_withdraw_timestamp = clock.unix_timestamp;

        vault.total_shares = vault.total_shares.checked_sub(shares_to_burn).unwrap();
        vault.total_sol = vault.total_sol.checked_sub(sol_to_return).unwrap();

        // If depositor fully withdrawn, decrement count
        if depositor_account.shares == 0 {
            vault.depositor_count = vault.depositor_count.checked_sub(1).unwrap();
        }

        emit!(Withdrawn {
            depositor: ctx.accounts.depositor.key(),
            shares_burned: shares_to_burn,
            sol_returned: sol_to_return,
            remaining_shares: depositor_account.shares,
            timestamp: clock.unix_timestamp,
        });

        msg!(
            "Withdraw: {} shares burned, {} lamports returned",
            shares_to_burn,
            sol_to_return
        );

        Ok(())
    }

    // ── Pause / Unpause ───────────────────────────────────────

    /// Manager can pause deposits (e.g. during maintenance).
    /// Withdrawals always remain open even when paused.
    pub fn set_paused(ctx: Context<ManagerOnly>, paused: bool) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        require!(
            ctx.accounts.manager.key() == vault.manager,
            VaultError::Unauthorized
        );
        vault.is_paused = paused;
        msg!("Vault paused: {}", paused);
        Ok(())
    }
}

// ── Account Structures ────────────────────────────────────────

#[account]
pub struct Vault {
    /// Manager/owner of this vault (your wallet)
    pub manager: Pubkey,             // 32
    /// Total shares outstanding across all depositors
    pub total_shares: u64,           // 8
    /// Total SOL (lamports) currently in the vault
    pub total_sol: u64,              // 8
    /// Cumulative profit ever earned
    pub total_profit_earned: u64,    // 8
    /// Cumulative fees paid to manager
    pub total_fees_collected: u64,   // 8
    /// Performance fee in basis points (2500 = 25%)
    pub performance_fee_bps: u64,    // 8
    /// Minimum deposit in lamports (500_000_000 = 0.5 SOL)
    pub min_deposit_lamports: u64,   // 8
    /// Withdrawal lockup in seconds (604800 = 7 days)
    pub withdrawal_lockup_seconds: i64, // 8
    /// Number of active depositors
    pub depositor_count: u64,        // 8
    /// Vault creation timestamp
    pub created_at: i64,             // 8
    /// Last time profit was recorded
    pub last_profit_update: i64,     // 8
    /// Whether deposits are paused
    pub is_paused: bool,             // 1
    /// PDA bump
    pub bump: u8,                    // 1
}

impl Vault {
    pub const LEN: usize = 8 + 32 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 1 + 1 + 64;
}

#[account]
pub struct DepositorAccount {
    /// The depositor's wallet
    pub depositor: Pubkey,           // 32
    /// The vault this account belongs to
    pub vault: Pubkey,               // 32
    /// Shares owned by this depositor
    pub shares: u64,                 // 8
    /// Total lamports ever deposited
    pub deposited_lamports: u64,     // 8
    /// Total lamports ever withdrawn
    pub total_withdrawn: u64,        // 8
    /// First deposit timestamp
    pub deposit_timestamp: i64,      // 8
    /// Last withdrawal timestamp (for lockup enforcement)
    pub last_withdraw_timestamp: i64, // 8
    /// PDA bump
    pub bump: u8,                    // 1
}

impl DepositorAccount {
    pub const LEN: usize = 8 + 32 + 32 + 8 + 8 + 8 + 8 + 8 + 1 + 32;
}

// ── Contexts ──────────────────────────────────────────────────

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = manager,
        space = Vault::LEN,
        seeds = [b"vault", manager.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, Vault>,

    /// The SOL holding PDA (holds actual lamports)
    #[account(
        mut,
        seeds = [b"vault_sol", vault.key().as_ref()],
        bump
    )]
    /// CHECK: This is a PDA that holds SOL — no data needed
    pub vault_sol: UncheckedAccount<'info>,

    #[account(mut)]
    pub manager: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Deposit<'info> {
    #[account(
        mut,
        seeds = [b"vault", vault.manager.as_ref()],
        bump = vault.bump
    )]
    pub vault: Account<'info, Vault>,

    #[account(
        mut,
        seeds = [b"vault_sol", vault.key().as_ref()],
        bump
    )]
    /// CHECK: SOL-holding PDA
    pub vault_sol: UncheckedAccount<'info>,

    #[account(
        init_if_needed,
        payer = depositor,
        space = DepositorAccount::LEN,
        seeds = [b"depositor", vault.key().as_ref(), depositor.key().as_ref()],
        bump
    )]
    pub depositor_account: Account<'info, DepositorAccount>,

    #[account(mut)]
    pub depositor: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RecordProfit<'info> {
    #[account(
        mut,
        seeds = [b"vault", vault.manager.as_ref()],
        bump = vault.bump
    )]
    pub vault: Account<'info, Vault>,

    #[account(
        mut,
        seeds = [b"vault_sol", vault.key().as_ref()],
        bump
    )]
    /// CHECK: SOL-holding PDA
    pub vault_sol: UncheckedAccount<'info>,

    #[account(mut)]
    pub manager: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(
        mut,
        seeds = [b"vault", vault.manager.as_ref()],
        bump = vault.bump
    )]
    pub vault: Account<'info, Vault>,

    #[account(
        mut,
        seeds = [b"vault_sol", vault.key().as_ref()],
        bump
    )]
    /// CHECK: SOL-holding PDA
    pub vault_sol: UncheckedAccount<'info>,

    #[account(
        mut,
        seeds = [b"depositor", vault.key().as_ref(), depositor.key().as_ref()],
        bump = depositor_account.bump
    )]
    pub depositor_account: Account<'info, DepositorAccount>,

    #[account(mut)]
    pub depositor: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ManagerOnly<'info> {
    #[account(
        mut,
        seeds = [b"vault", vault.manager.as_ref()],
        bump = vault.bump
    )]
    pub vault: Account<'info, Vault>,

    #[account(mut)]
    pub manager: Signer<'info>,
}

// ── Errors ────────────────────────────────────────────────────

#[error_code]
pub enum VaultError {
    #[msg("You are not authorized to perform this action")]
    Unauthorized,
    #[msg("Deposit amount is below the minimum of 0.5 SOL")]
    BelowMinimumDeposit,
    #[msg("Vault is at maximum capacity (100 depositors)")]
    VaultFull,
    #[msg("Share calculation resulted in zero — try a larger deposit")]
    ZeroShares,
    #[msg("Profit amount must be greater than zero")]
    ZeroProfit,
    #[msg("Withdrawal amount is zero")]
    ZeroWithdrawal,
    #[msg("Insufficient shares to withdraw")]
    InsufficientShares,
    #[msg("Withdrawals are locked for 7 days between requests")]
    WithdrawalLocked,
    #[msg("Vault is currently paused — deposits not accepted")]
    VaultPaused,
}

// ── Events ────────────────────────────────────────────────────

#[event]
pub struct VaultInitialized {
    pub manager: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct Deposited {
    pub depositor: Pubkey,
    pub amount_lamports: u64,
    pub shares_minted: u64,
    pub total_vault_sol: u64,
    pub timestamp: i64,
}

#[event]
pub struct ProfitRecorded {
    pub profit_lamports: u64,
    pub fee_lamports: u64,
    pub net_profit: u64,
    pub manager: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct Withdrawn {
    pub depositor: Pubkey,
    pub shares_burned: u64,
    pub sol_returned: u64,
    pub remaining_shares: u64,
    pub timestamp: i64,
}
